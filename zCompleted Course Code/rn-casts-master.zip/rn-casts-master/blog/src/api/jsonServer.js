import axios from 'axios';

export default axios.create({
  baseURL: 'http://023ac250.ngrok.io'
});
